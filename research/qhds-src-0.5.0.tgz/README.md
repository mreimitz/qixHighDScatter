# qixHighDScatter

A Qlik Sense extension (nebula.js supernova) that brings the brand-ui `DensityScatterChart` into Qlik.
It handles 100k–1M points: every point is drawn with WebGL and coloured by density, zones on the axes classify the points, and selections behave the way the native Qlik scatter's do.

Design and decisions: `research/CONCEPT.md`. Test data: `research/test-data.qvs`.

## Install (no coding needed)

1. Take `release/qixHighDScatter-v<version>.zip`.
2. Upload it as an extension.
   - Qlik Cloud: Administration › Extensions › Add.
   - Client-managed: QMC › Extensions › Import.
3. In a sheet, open Custom objects › **High Density Scatter**.
   - Add a point dimension with one row per point, e.g. `PointID`.
   - Add a measure for X and one for Y, e.g. `Only(AlongTrack)` and `Only(CrossTrack)`.
   - An optional third measure colours the points by value. An optional second dimension colours them by category.

## Configure zones (Add-ons › Zones)

- **Zones from Properties.** An ordered list where the first match wins (inner zones before outer ones). Each zone has a label, a colour, a show switch and one of three types:
  - *Horizontal band*: Y min/max.
  - *Rectangle*: X and Y min/max.
  - *Envelope along X*: upper points, plus lower points or "mirror".
  - Every coordinate accepts an expression, e.g. `=vCoreLimit`.
- **Zones from Data model.** A zone table with one row per vertex, mapped by field names: `ZoneID, ZoneLabel, ZoneColor, ZoneEdge (upper|lower|min|max), ZoneSeq, ZoneX, ZoneY`.

## Interaction

- The wheel zooms and dragging pans.
- The toolbar has three tools:
  - **Pointer.**
  - **Range:** a box that sets X and Y at once. Dragging an axis gutter sets one axis.
  - **Lasso.**
- **Legend:** a click hides a zone. Shift/Ctrl-click selects the zone.

Selections are Qlik selections:
- Ranges and boxes use `rangeSelectHyperCubeValues` on the two measures.
- Lassos and envelope zones become up to 64 vertical strips, sent as `multiRangeSelectHyperCubeValues`, which is how the native scatter does it.
- Confirm or cancel with the Qlik selection toolbar.

## Develop

```bash
npm install
npm run build        # → extension/qixHighDScatter/ (AMD bundle, qext, stubs)
npm run package      # → release/qixHighDScatter-v<version>.zip
node test/run-harness.mjs "?n=300000"   # real nebula.js runtime + EnigmaMocker in Chromium
node test/selection-test.mjs            # drives range / lasso / legend, records engine calls
```

Build notes:
- `@nebula.js/stardust` is the only external. React, brand-ui and their dependencies are bundled.
- The brand-ui Tailwind CSS is compiled, then scoped to `.qhds` with its cascade layers unwrapped and its `@font-face` rules dropped. It is injected once.
- Colours, fonts, grid and surfaces come from the Qlik app theme (`src/theme.ts`).
