// Real nebula.js runtime + EnigmaMocker. Generates N synthetic points (funnel
// traffic like the brand-ui story) and records every engine call.
const params = new URLSearchParams(location.search);
const N = Number(params.get('n') || 300000);
const DARK = params.get('dark') === '1';
window.__calls = [];
if (DARK) document.getElementById('obj').style.background = '#1e1e1e';
function lcg(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
const rnd = lcg(20260925);
const gauss = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const X = new Float64Array(N), Y = new Float64Array(N), V = new Float64Array(N);
for (let i = 0; i < N; i++) {
  const r = rnd(); let px = -2200 + rnd() * 5700, py;
  if (r < 0.75) { const sd = px < -650 ? 16 : px < -200 ? 16 - (11 * (px + 650)) / 450 : 5; py = gauss() * sd; }
  else if (r < 0.95) { py = gauss() * (px < -200 ? 60 : 14); }
  else py = gauss() * 140;
  X[i] = px; Y[i] = py; V[i] = 80 + 80 * Math.min(1, Math.max(0, (px + 2200) / 5700)) + gauss() * 8;
}
const cell = (n, t) => ({ qNum: n, qText: t ?? String(n), qElemNumber: 0, qState: 'L' });
const zones = JSON.parse(params.get('zones') || 'null') || [
  { label: 'Core', show: true, kind: 'envelope', mirror: true, upper: [{ x: -2200, y: 42 }, { x: -650, y: 42 }, { x: -200, y: 15 }, { x: 3500, y: 15 }], color: { index: -1, color: '#4477aa' } },
  { label: 'Expanded', show: true, kind: 'envelope', mirror: false, upper: [{ x: -1450, y: 215 }, { x: -200, y: 30 }, { x: 3500, y: 30 }], lower: [{ x: -1300, y: -215 }, { x: -200, y: -30 }, { x: 3500, y: -30 }], color: { index: 3 } },
  { label: 'High band', show: true, kind: 'band', yMin: 200, yMax: 400, color: { index: -1, color: '#f93f17' } },
  { label: 'Broken', show: true, kind: 'rect', yMin: 0, yMax: 1 },
];
const layout = {
  qInfo: { qId: 'qhds1', qType: 'qixHighDScatter' },
  visualization: 'qixHighDScatter',
  title: 'Harness', showTitles: false,
  qSelectionInfo: {},
  qHyperCube: {
    qSize: { qcx: 4, qcy: N },
    qDimensionInfo: [{ cId: 'd1', qFallbackTitle: 'PointID', qCardinal: N, qStateCounts: { qOption: N } }],
    qMeasureInfo: [{ cId: 'm1', qFallbackTitle: 'Along-track (m)', qMin: -2200, qMax: 3500 }, { cId: 'm2', qFallbackTitle: 'Cross-track (m)', qMin: -500, qMax: 500 }, { cId: 'm3', qFallbackTitle: 'Speed', qMin: 60, qMax: 190 }],
    qDataPages: [],
  },
  props: { zones, outsideLabel: 'Outside', outsideColor: { index: -1, color: '#a6a6a6' }, colorBy: params.get('colorBy') || 'zone', pointRadius: 1.35, cellSize: 5, underlay: 4, maxPoints: 1000000, zoom: true, toolbar: true, legend: true },
};
let pagesServed = 0;
const rec = (name) => (...args) => { window.__calls.push({ name, args: JSON.parse(JSON.stringify(args)) }); return name === 'rangeSelectHyperCubeValues' || name === 'multiRangeSelectHyperCubeValues' ? true : undefined; };
const genericObject = {
  getLayout: () => layout,
  getProperties: () => ({ qInfo: layout.qInfo, props: layout.props }),
  getEffectiveProperties: () => ({ qInfo: layout.qInfo, props: layout.props }),
  getHyperCubeData: (path, pages) => pages.map((p) => {
    pagesServed++;
    const qMatrix = [];
    for (let r = p.qTop; r < Math.min(N, p.qTop + p.qHeight); r++) qMatrix.push([cell(r, 'P' + r), cell(X[r]), cell(Y[r]), cell(V[r])]);
    return { qArea: p, qMatrix };
  }),
  beginSelections: rec('beginSelections'),
  endSelections: rec('endSelections'),
  resetMadeSelections: rec('resetMadeSelections'),
  clearSelections: rec('clearSelections'),
  rangeSelectHyperCubeValues: rec('rangeSelectHyperCubeValues'),
  multiRangeSelectHyperCubeValues: rec('multiRangeSelectHyperCubeValues'),
};
window.__pages = () => pagesServed;
(async () => {
  const t0 = performance.now();
  const app = await stardust.EnigmaMocker.fromGenericObjects([genericObject], { delay: 5 });
  if (params.get('zsrc') === 'data') {
    layout.props.zoneSource = 'data';
    // zone table: one row per vertex (ZoneID, Label, Color, Edge, Seq, X, Y)
    const t = (v) => (v === null ? { qText: '-', qNum: NaN, qIsNull: true } : typeof v === 'number' ? { qText: String(v), qNum: v } : { qText: v, qNum: NaN });
    const rows = [
      ['core', 'Core (table)', '#2e7d32', 'upper', 1, -2200, 42], ['core', 'Core (table)', '#2e7d32', 'upper', 2, -650, 42], ['core', 'Core (table)', '#2e7d32', 'upper', 3, -200, 15], ['core', 'Core (table)', '#2e7d32', 'upper', 4, 3500, 15],
      ['box', 'Box (table)', 4, 'min', 1, 500, -150], ['box', 'Box (table)', 4, 'max', 2, 1500, -60],
      ['band', 'Band (table)', '#8e44ad', 'min', 1, null, 250], ['band', 'Band (table)', '#8e44ad', 'max', 2, null, 450],
    ].map((r) => r.map(t));
    window.__sessionObjects = [];
    app.createSessionObject = async (def) => {
      window.__sessionObjects.push(def);
      return { id: 'zones-so', on() {}, removeListener() {}, getLayout: async () => ({ qHyperCube: { qDataPages: [{ qMatrix: rows }] } }) };
    };
    app.destroySessionObject = async (id) => { window.__destroyed = id; };
  }
  const nebbie = stardust.embed(app, {
    context: { theme: DARK ? 'dark' : 'light', constraints: {}, interactions: { select: true, active: true, passive: false } },
    types: [{ name: 'qixHighDScatter', load: () => Promise.resolve(window.__qhds) }],
  });
  window.__viz = await nebbie.render({ element: document.getElementById('obj'), id: 'qhds1' });
  window.__rendered = performance.now() - t0;
})().catch((e) => { window.__error = String(e && e.stack || e); console.error(e); });
