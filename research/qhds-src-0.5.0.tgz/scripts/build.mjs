// Build: Tailwind (brand-ui) CSS → scoped → inlined; esbuild TSX bundle (React +
// brand-ui charts); AMD wrapper with @nebula.js/stardust as the only external.
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync, copyFileSync } from "node:fs";
import { build } from "esbuild";
import scopeCss from "./scope-css.mjs";

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const NAME = "qixHighDScatter";
const VERSION = pkg.version;
const dev = process.argv.includes("--dev");
mkdirSync("build", { recursive: true });
mkdirSync(`extension/${NAME}`, { recursive: true });

execFileSync("node", ["node_modules/@tailwindcss/cli/dist/index.mjs", "-i", "src/styles.css", "-o", "build/tw.css", ...(dev ? [] : ["--minify"])], { stdio: "inherit" });
const scoped = scopeCss(readFileSync("build/tw.css", "utf8"));
writeFileSync("src/styles.generated.css", scoped);

const res = await build({
  entryPoints: ["src/index.tsx"],
  bundle: true,
  format: "cjs",
  platform: "browser",
  target: ["es2020"],
  jsx: "automatic",
  minify: !dev,
  sourcemap: false,
  external: ["@nebula.js/stardust"],
  loader: { ".css": "text" },
  define: { "process.env.NODE_ENV": dev ? '"development"' : '"production"', __QHDS_VERSION__: JSON.stringify(VERSION) },
  write: false,
  legalComments: "none",
  metafile: true,
});
let code = res.outputFiles[0].text.replace(/__QHDS_VERSION__/g, VERSION);
// String concatenation (not a template literal): minified libs contain backticks and ${.
const amd =
  "/* " + NAME + " v" + VERSION + " */\n" +
  "define(['@nebula.js/stardust'], function (__stardust) {\n" +
  "var module = { exports: {} }, exports = module.exports;\n" +
  "var require = function (n) { if (n === '@nebula.js/stardust') return __stardust; throw new Error('qixHighDScatter: unexpected require ' + n); };\n" +
  code +
  "\nvar __m = module.exports; return __m && __m.default ? __m.default : __m;\n});\n";
const out = `extension/${NAME}`;
writeFileSync(`${out}/${NAME}.js`, amd);
writeFileSync(
  `${out}/${NAME}.qext`,
  JSON.stringify(
    {
      name: "High Density Scatter",
      description: "Scatter plot for 100k–1M points: every point drawn, coloured by density, classified by zones on the axes.",
      type: "visualization",
      version: VERSION,
      author: "Manuel Reimitz",
      icon: "scatterChart",
      preview: "",
      supernova: true,
    },
    null,
    2,
  ) + "\n",
);
writeFileSync(`${out}/${NAME}.html`, "<!DOCTYPE html><html><head></head><body></body></html>\n");
writeFileSync(`${out}/${NAME}.css`, "/* styles are injected by the extension (scoped to .qhds) */\n");
writeFileSync("build/meta.json", JSON.stringify(res.metafile));
console.log(`built ${out}/${NAME}.js  ${(amd.length / 1024).toFixed(0)} KB  (css ${(scoped.length / 1024).toFixed(0)} KB)`);
