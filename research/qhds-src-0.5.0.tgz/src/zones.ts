/**
 * Layout (engine-evaluated properties) → DensityScatterChart zones.
 * Every coordinate may have been an expression; the layout already holds numbers.
 * Invalid zones are reported, never thrown, so the chart can show a warning chip.
 */
import type { DensityZone } from "@elabs-ai/components-charts";

export interface ZoneIssue {
  zone: string;
  message: string;
}

const n = (v: unknown): number => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" ? Number(v) : NaN);

type Pt = [number, number];

function points(list: any[] | undefined): Pt[] {
  return (list ?? [])
    .map((p) => [n(p?.x), n(p?.y)] as Pt)
    .filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]));
}

export function toDensityZones(
  raw: any[] | undefined,
  resolveColor: (c: any, index: number) => string,
): { zones: DensityZone[]; issues: ZoneIssue[] } {
  const zones: DensityZone[] = [];
  const issues: ZoneIssue[] = [];
  (raw ?? []).forEach((z, i) => {
    const label = String(z?.label ?? `Zone ${i + 1}`) || `Zone ${i + 1}`;
    if (z?.show === false || z?.show === 0) return;
    if (zones.length >= 15) {
      issues.push({ zone: label, message: "At most 15 zones are drawn." });
      return;
    }
    const id = z?.cId || `z${i}`;
    const color = resolveColor(z?.color, i);
    const kind = z?.kind || "band";
    if (kind === "envelope") {
      const upper = points(z?.upper);
      const lower = z?.mirror === false ? points(z?.lower) : upper.map(([x, y]) => [x, -y] as Pt);
      if (upper.length < 2 || lower.length < 2) {
        issues.push({ zone: label, message: "Envelope needs at least 2 valid points on each edge." });
        return;
      }
      zones.push({ id, label, color, bounds: { upper, lower } });
      return;
    }
    const y0 = n(z?.yMin);
    const y1 = n(z?.yMax);
    if (!Number.isFinite(y0) || !Number.isFinite(y1)) {
      issues.push({ zone: label, message: "Y min / Y max must be numbers." });
      return;
    }
    if (kind === "rect") {
      const x0 = n(z?.xMin);
      const x1 = n(z?.xMax);
      if (!Number.isFinite(x0) || !Number.isFinite(x1)) {
        issues.push({ zone: label, message: "X min / X max must be numbers." });
        return;
      }
      zones.push({ id, label, color, bounds: { x: [Math.min(x0, x1), Math.max(x0, x1)], y: [Math.min(y0, y1), Math.max(y0, y1)] } });
      return;
    }
    zones.push({ id, label, color, bounds: { y: [Math.min(y0, y1), Math.max(y0, y1)] } });
  });
  return { zones, issues };
}
