import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  DensityScatterChart,
  type DensityColorBy,
  type DensityScatterSelection,
  type DensityZone,
} from "@elabs-ai/components-charts";
import { fetchAllRows, type QhdsColumns } from "./data";
import { toDensityZones } from "./zones";
import { watchZoneTable } from "./data-zones";
import { planSelection, toEngineSelect } from "./selection";
import type { QhdsTheme } from "./theme";

export interface AppProps {
  layout: any;
  model: any;
  app: any;
  selections: any;
  theme: QhdsTheme;
  width: number;
  height: number;
  /** Selecting allowed (analysis mode, not passive, not in edit). */
  canSelect: boolean;
  /** Passive (snapshot / print / tiny): no interaction at all. */
  passive: boolean;
}

const EMPTY: QhdsColumns = { x: new Float32Array(0), y: new Float32Array(0), n: 0, total: 0, done: false };

function dataKey(layout: any): string {
  const hc = layout?.qHyperCube;
  if (!hc) return "";
  return JSON.stringify([
    hc.qSize,
    (hc.qDimensionInfo || []).map((d: any) => [d.cId, d.qFallbackTitle, d.qCardinal, d.qStateCounts]),
    (hc.qMeasureInfo || []).map((m: any) => [m.cId, m.qFallbackTitle, m.qMin, m.qMax]),
    layout?.props?.maxPoints,
  ]);
}

function fmt(n: number): string {
  return n.toLocaleString();
}

export function App({ layout, model, app, selections, theme, width, height, canSelect, passive }: AppProps) {
  const hc = layout?.qHyperCube;
  const props = layout?.props ?? {};
  const inSelections = Boolean(layout?.qSelectionInfo?.qInSelections);

  // ---------- data ----------
  const [cols, setCols] = useState<QhdsColumns>(EMPTY);
  const [version, setVersion] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const key = dataKey(layout);
  const lastKey = useRef<string>("");
  useEffect(() => {
    if (!hc || hc.qError || hc.qCalcCondMsg) return;
    if (hc.qDimensionInfo.length < 1 || hc.qMeasureInfo.length < 2) return;
    // Engine data of an object in its own selection session is frozen; refetch once it ends.
    if (inSelections) return;
    if (key === lastKey.current) return;
    lastKey.current = key;
    setError(null);
    const handle = fetchAllRows(
      model,
      hc,
      Math.max(1000, Number(props.maxPoints) || 1_000_000),
      (c) => {
        setCols(c);
        setVersion((v) => v + 1);
      },
      (e) => setError(String((e as any)?.message ?? e)),
    );
    return () => {
      handle.cancel();
      // allow the same key to be fetched again if this effect was torn down mid-way
      lastKey.current = "";
    };
  }, [key, inSelections]); // eslint-disable-line react-hooks/exhaustive-deps

  // The chart treats `data` identity as "data changed": hand it a new wrapper per progress step.
  const data = useMemo(() => {
    const out: any = { x: cols.x.subarray(0, cols.n), y: cols.y.subarray(0, cols.n) };
    if (cols.values) out.values = { value: cols.values.value!.subarray(0, cols.n) };
    if (cols.categories) {
      const c = cols.categories.category!;
      out.categories = { category: Array.from(c.codes.subarray(0, cols.n), (k) => c.labels[k] ?? "") };
    }
    return out;
  }, [version]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---------- zones ----------
  const fromData = props.zoneSource === "data";
  const zoneFieldsKey = JSON.stringify(props.zoneFields ?? {});
  const [dataZones, setDataZones] = useState<{ raw: any[]; error?: string }>({ raw: [] });
  useEffect(() => {
    if (!fromData || !app) return;
    return watchZoneTable(app, props.zoneFields ?? {}, (raw, error) => setDataZones({ raw, error }));
  }, [fromData, app, zoneFieldsKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const { zones, issues } = useMemo(() => {
    const r = toDensityZones(fromData ? dataZones.raw : props.zones, theme.resolveColor);
    if (fromData && dataZones.error) r.issues.unshift({ zone: "Zone table", message: dataZones.error });
    return r;
  }, [layout, theme, fromData, dataZones]);
  const outside = useMemo(
    () => ({ label: String(props.outsideLabel ?? "Outside"), color: theme.resolveColor(props.outsideColor, 7) }),
    [layout, theme],
  );

  const chartKey = useMemo(() => JSON.stringify([props.colorBy, zones]), [props.colorBy, zones]);
  const nMeas = hc?.qMeasureInfo?.length ?? 0;
  const nDims = hc?.qDimensionInfo?.length ?? 0;
  const colorBy: DensityColorBy = useMemo(() => {
    const want = props.colorBy || "zone";
    if (want === "value" && nMeas >= 3) return { kind: "value", key: "value" };
    if (want === "category" && nDims >= 2) return { kind: "category", key: "category" };
    if (want === "density" || zones.length === 0) return { kind: "density" };
    return { kind: "zone" };
  }, [props.colorBy, nMeas, nDims, zones.length]);

  // ---------- selections (Qlik semantics) ----------
  const [selection, setSelection] = useState<DensityScatterSelection | undefined>(undefined);
  const zonesRef = useRef<DensityZone[]>(zones);
  zonesRef.current = zones;
  const busy = useRef(false);
  const pending = useRef<DensityScatterSelection | undefined | null>(null);

  useEffect(() => {
    if (!selections) return;
    const reset = () => setSelection(undefined);
    const on = selections.addListener?.bind(selections) ?? selections.on?.bind(selections);
    const off = selections.removeListener?.bind(selections) ?? selections.off?.bind(selections);
    if (!on) return;
    for (const ev of ["deactivated", "canceled", "cleared", "confirmed"]) on(ev, reset);
    return () => {
      if (off) for (const ev of ["deactivated", "canceled", "cleared", "confirmed"]) off(ev, reset);
    };
  }, [selections]);

  // Not in a selection session any more (e.g. confirmed from outside): drop the preview.
  useEffect(() => {
    if (!inSelections && selections && !selections.isActive?.()) setSelection(undefined);
  }, [inSelections, selections]);

  const pushToEngine = useCallback(
    async (sel: DensityScatterSelection | undefined) => {
      if (!selections) return;
      if (busy.current) {
        pending.current = sel ?? null;
        return;
      }
      busy.current = true;
      try {
        if (!selections.isActive()) await selections.begin(["/qHyperCubeDef"]);
        const plan = planSelection(sel, zonesRef.current);
        await selections.select(toEngineSelect(plan));
      } catch (e) {
        // eslint-disable-next-line no-console
        console.warn("[qixHighDScatter] selection failed", e);
      } finally {
        busy.current = false;
        if (pending.current !== null) {
          const next = pending.current;
          pending.current = null;
          void pushToEngine(next ?? undefined);
        }
      }
    },
    [selections],
  );

  const onSelectionChange = useCallback(
    (next: DensityScatterSelection) => {
      if (!canSelect) return;
      setSelection(next);
      void pushToEngine(next);
    },
    [canSelect, pushToEngine],
  );

  // ---------- legend hide (session only) ----------
  const [hiddenKeys, setHiddenKeys] = useState<ReadonlySet<string>>(() => new Set());

  // ---------- size ----------
  const legendOn = props.legend !== false && colorBy.kind !== "density" && colorBy.kind !== "value";
  const toolbarOn = canSelect && props.toolbar !== false;
  // Fit: start from an estimate of the chart chrome (toolbar, legend, axis title),
  // then correct by what the rendered chart actually overflows / underfills.
  const estimate = (legendOn ? 36 : 0) + (toolbarOn ? 44 : 0) + 36;
  const [fix, setFix] = useState(0);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const plotHeight = Math.max(80, Math.floor(height - estimate - fix));
  useLayoutEffect(() => {
    const chart = frameRef.current?.firstElementChild as HTMLElement | null;
    if (!chart) return;
    const over = chart.getBoundingClientRect().height - height;
    if (Math.abs(over) > 2 && plotHeight > 80) setFix((f) => Math.max(-estimate, f + Math.ceil(over)));
  });
  useEffect(() => setFix(0), [legendOn, toolbarOn, height]);

  const status = !hc
    ? null
    : hc.qCalcCondMsg
      ? hc.qCalcCondMsg
      : hc.qError
        ? `Error: ${hc.qError.qErrorCode}`
        : nDims < 1 || nMeas < 2
          ? "Add a point dimension (one row per point) and two measures for X and Y."
          : error
            ? `Could not load data: ${error}`
            : null;

  // The engine knows the extents before the first page lands: a stable domain
  // means no re-framing while points stream in.
  const domain = useMemo(() => {
    const mx = hc?.qMeasureInfo?.[0];
    const my = hc?.qMeasureInfo?.[1];
    if (!mx || !my) return undefined;
    const ok = (v: unknown) => typeof v === "number" && Number.isFinite(v);
    if (!ok(mx.qMin) || !ok(mx.qMax) || !ok(my.qMin) || !ok(my.qMax)) return undefined;
    const pad = (a: number, b: number) => {
      const d = b - a || Math.abs(a) || 1;
      return [a - d * 0.03, b + d * 0.03];
    };
    const [x0, x1] = pad(mx.qMin, mx.qMax);
    const [y0, y1] = pad(my.qMin, my.qMax);
    return { x0: x0!, x1: x1!, y0: y0!, y1: y1! };
  }, [hc?.qMeasureInfo?.[0]?.qMin, hc?.qMeasureInfo?.[0]?.qMax, hc?.qMeasureInfo?.[1]?.qMin, hc?.qMeasureInfo?.[1]?.qMax]);

  const formatter = useMemo(() => {
    const nf = new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 });
    return (v: number) => nf.format(v);
  }, []);

  if (width < 40 || height < 40) return null;

  if (status) {
    return (
      <div className="qhds-empty" style={{ width, height }}>
        <span>{status}</span>
      </div>
    );
  }

  const xTitle = hc.qMeasureInfo[0]?.qFallbackTitle;
  const yTitle = hc.qMeasureInfo[1]?.qFallbackTitle;
  const loading = !cols.done;

  return (
    <div className="qhds-frame" ref={frameRef} style={{ width, height }}>
      <DensityScatterChart
        // Workaround (brand-ui 5.5.0): changing colorBy / zones after the points are
        // uploaded leaves the WebGL layer without dots. Remount on a zone/colour change.
        key={chartKey}
        accessibleLabel={layout?.title || `${yTitle} by ${xTitle}`}
        data={data}
        zones={colorBy.kind === "zone" ? zones : zones}
        outside={outside}
        colorBy={colorBy}
        valueKey={nMeas >= 3 ? "value" : undefined}
        xLabel={xTitle}
        yLabel={yTitle}
        formatX={formatter}
        formatY={formatter}
        formatValue={formatter}
        pointRadius={Number(props.pointRadius) || 1.35}
        cellSize={Number(props.cellSize) || 5}
        underlay={Number.isFinite(Number(props.underlay)) ? Number(props.underlay) : 4}
        zoom={!passive && props.zoom !== false}
        legend={legendOn ? { interactive: "toggle" } : false}
        hiddenKeys={hiddenKeys}
        onHiddenKeysChange={setHiddenKeys}
        selection={selection}
        onSelectionChange={onSelectionChange}
        selectionGestures={canSelect ? ["range", "lasso"] : undefined}
        onSelectionIntent={canSelect ? () => undefined : undefined}
        selectionToolbar={toolbarOn ? "auto" : "none"}
        plotHeight={plotHeight}
        domain={domain}
      />
      {(loading || issues.length > 0) && (
        <div className="qhds-status" aria-live="polite">
          {loading && cols.total > 0 && (
            <span>
              Loading {fmt(cols.n)} / {fmt(cols.total)} points
            </span>
          )}
          {issues.map((i) => (
            <span key={i.zone + i.message} className="qhds-warn">
              {i.zone}: {i.message}
            </span>
          ))}
        </div>
      )}
      {hc.qSize.qcy > (Number(props.maxPoints) || 1_000_000) && cols.done && (
        <div className="qhds-status">
          <span className="qhds-warn">
            Showing {fmt(cols.total)} of {fmt(hc.qSize.qcy)} rows (max points in Add-ons › Data handling)
          </span>
        </div>
      )}
    </div>
  );
}
