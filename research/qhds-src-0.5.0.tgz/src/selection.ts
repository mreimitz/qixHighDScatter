/**
 * The chart's intersection selection → engine range selections, the way the
 * native scatter does it (decision D3): axis ranges and boxes are exact
 * rectangles; a lasso or an envelope zone is converted into vertical strips
 * (rectangles) and everything is sent as ONE `multiRangeSelectHyperCubeValues`
 * (entries OR'ed, x AND y inside an entry). Empty → `resetMadeSelections`.
 */
import type { DensityScatterSelection, DensityZone } from "@elabs-ai/components-charts";

export interface Rect {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
}

const BIG = Number.MAX_VALUE;
const ALL: Rect = { x0: -BIG, x1: BIG, y0: -BIG, y1: BIG };
/** Strips per lasso / envelope. Native uses a comparable resolution; 64 keeps the message small. */
export const STRIPS = 64;

type Pt = readonly [number, number];

/** Vertical strips covering a polygon: at each strip's centre x, the inside y-intervals. */
export function polygonToRects(poly: ReadonlyArray<Pt>, strips = STRIPS): Rect[] {
  if (poly.length < 3) return [];
  let minX = Infinity;
  let maxX = -Infinity;
  for (const [x] of poly) {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
  }
  if (!(maxX > minX)) return [];
  const w = (maxX - minX) / strips;
  const out: Rect[] = [];
  for (let s = 0; s < strips; s++) {
    const x0 = minX + s * w;
    const x1 = x0 + w;
    // Sample the crossing y-values at both strip edges and the centre; take the
    // union envelope of intervals found at the centre, widened by the edges.
    const ys = (cx: number) => {
      const hits: number[] = [];
      for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
        const [xi, yi] = poly[i]!;
        const [xj, yj] = poly[j]!;
        if (xi > cx !== xj > cx) hits.push(yi + ((cx - xi) * (yj - yi)) / (xj - xi));
      }
      return hits.sort((a, b) => a - b);
    };
    const centre = ys((x0 + x1) / 2);
    const left = ys(x0 + w * 0.01);
    const right = ys(x1 - w * 0.01);
    for (let k = 0; k + 1 < centre.length; k += 2) {
      let lo = centre[k]!;
      let hi = centre[k + 1]!;
      // widen by the nearest edge crossings so thin slanted parts are not lost
      for (const arr of [left, right]) {
        for (let m = 0; m + 1 < arr.length; m += 2) {
          if (arr[m + 1]! >= lo && arr[m]! <= hi) {
            lo = Math.min(lo, arr[m]!);
            hi = Math.max(hi, arr[m + 1]!);
          }
        }
      }
      out.push({ x0, x1, y0: lo, y1: hi });
    }
  }
  return out;
}

function polylineAt(poly: ReadonlyArray<Pt>, x: number): number {
  const p = [...poly].sort((a, b) => a[0] - b[0]);
  if (x <= p[0]![0]) return p[0]![1];
  for (let i = 1; i < p.length; i++) {
    const [ax, ay] = p[i - 1]!;
    const [bx, by] = p[i]!;
    if (x <= bx) return bx === ax ? by : ay + ((by - ay) * (x - ax)) / (bx - ax);
  }
  return p[p.length - 1]![1];
}

export function zoneToRects(zone: DensityZone, strips = STRIPS): Rect[] {
  const b: any = zone.bounds;
  if ("upper" in b) {
    const xs = [...b.upper, ...b.lower].map((p: Pt) => p[0]);
    const minX = Math.max(Math.min(...b.upper.map((p: Pt) => p[0])), Math.min(...b.lower.map((p: Pt) => p[0])));
    const maxX = Math.min(Math.max(...b.upper.map((p: Pt) => p[0])), Math.max(...b.lower.map((p: Pt) => p[0])));
    if (!(maxX > minX) || xs.length < 4) return [];
    const w = (maxX - minX) / strips;
    const out: Rect[] = [];
    for (let s = 0; s < strips; s++) {
      const x0 = minX + s * w;
      const x1 = x0 + w;
      let lo = Infinity;
      let hi = -Infinity;
      for (const x of [x0, (x0 + x1) / 2, x1]) {
        const u = polylineAt(b.upper, x);
        const l = polylineAt(b.lower, x);
        lo = Math.min(lo, u, l);
        hi = Math.max(hi, u, l);
      }
      out.push({ x0, x1, y0: lo, y1: hi });
    }
    return out;
  }
  const [x0, x1] = b.x ?? [-BIG, BIG];
  return [{ x0, x1, y0: b.y[0], y1: b.y[1] }];
}

function intersect(a: Rect[], b: Rect[]): Rect[] {
  const out: Rect[] = [];
  for (const r of a)
    for (const s of b) {
      const x0 = Math.max(r.x0, s.x0);
      const x1 = Math.min(r.x1, s.x1);
      const y0 = Math.max(r.y0, s.y0);
      const y1 = Math.min(r.y1, s.y1);
      if (x0 <= x1 && y0 <= y1) out.push({ x0, x1, y0, y1 });
    }
  return out;
}

export interface EnginePlan {
  /** `null` = no constraint (reset). */
  rects: Rect[] | null;
  /** The outside class cannot be expressed as ranges; it is ignored as a zone constraint. */
  ignoredOutside: boolean;
}

export function planSelection(selection: DensityScatterSelection | undefined, zones: readonly DensityZone[]): EnginePlan {
  let rects: Rect[] | null = null;
  let ignoredOutside = false;
  const apply = (set: Rect[]) => {
    rects = rects === null ? set : intersect(rects, set);
  };
  if (!selection) return { rects: null, ignoredOutside };
  if (selection.x) apply([{ ...ALL, x0: Math.min(...selection.x), x1: Math.max(...selection.x) }]);
  if (selection.y) apply([{ ...ALL, y0: Math.min(...selection.y), y1: Math.max(...selection.y) }]);
  if (selection.lasso && selection.lasso.length >= 3) apply(polygonToRects(selection.lasso));
  if (selection.zones?.length) {
    const set: Rect[] = [];
    for (const id of selection.zones) {
      const z = zones.find((q) => q.id === id);
      if (z) set.push(...zoneToRects(z));
      else ignoredOutside = true;
    }
    if (set.length) apply(set);
  }
  return { rects, ignoredOutside };
}

const range = (ix: number, lo: number, hi: number) => ({
  qMeasureIx: ix,
  qRange: { qMin: lo, qMax: hi, qMinInclEq: true, qMaxInclEq: true },
});

/** The stardust `selections.select(...)` argument for a plan. */
export function toEngineSelect(plan: EnginePlan): { method: string; params: unknown[] } {
  if (plan.rects === null) return { method: "resetMadeSelections", params: [] };
  const rects = plan.rects.length ? plan.rects : [{ x0: 1, x1: 0, y0: 1, y1: 0 }]; // empty → selects nothing
  if (rects.length === 1) {
    const r = rects[0]!;
    return {
      method: "rangeSelectHyperCubeValues",
      params: ["/qHyperCubeDef", [range(0, r.x0, r.x1), range(1, r.y0, r.y1)], [], false],
    };
  }
  return {
    method: "multiRangeSelectHyperCubeValues",
    params: ["/qHyperCubeDef", rects.map((r) => ({ qRanges: [range(0, r.x0, r.x1), range(1, r.y0, r.y1)] }))],
  };
}
