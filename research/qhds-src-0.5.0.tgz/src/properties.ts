/**
 * qixHighDScatter — initial properties + property-panel definition.
 *
 * Panel layout mirrors the native Qlik scatter: Data → Sorting → Add-ons (Zones,
 * Reference lines, data handling) → Appearance (Presentation). Stock components
 * only (no styling-panel, no custom components) — both silently break uploaded
 * extensions' panels.
 */

export const MAX_ZONES = 15;

const num = (ref: string, label: string, defaultValue?: number, show?: (d: any) => boolean) => ({
  ref,
  label,
  type: "number",
  expression: "optional",
  ...(defaultValue !== undefined ? { defaultValue } : {}),
  ...(show ? { show } : {}),
});

const pointList = (ref: string, label: string, add: string, show: (d: any) => boolean) => ({
  type: "array",
  ref,
  label,
  itemTitleRef: (item: any, index: number) => `Point ${index + 1}`,
  allowAdd: true,
  allowRemove: true,
  allowMove: true,
  addTranslation: add,
  show,
  items: {
    x: num("x", "X"),
    y: num("y", "Y"),
  },
});

const isKind = (k: string) => (d: any) => (d.kind || "band") === k;
const isNotKind = (k: string) => (d: any) => (d.kind || "band") !== k;

export const initialProperties = {
  qInfo: { qType: "qixHighDScatter" },
  version: 1,
  showTitles: true,
  title: "",
  subtitle: "",
  footnote: "",
  components: [],
  qHyperCubeDef: {
    qDimensions: [],
    qMeasures: [],
    qMode: "S",
    qSuppressMissing: true,
    qSuppressZero: false,
    qInterColumnSortOrder: [],
    // Rows are fetched by the extension in 10k-cell pages; keep the layout light.
    qInitialDataFetch: [{ qWidth: 0, qHeight: 0 }],
  },
  props: {
    zones: [],
    zoneSource: "props",
    zoneFields: { id: "ZoneID", label: "ZoneLabel", color: "ZoneColor", edge: "ZoneEdge", seq: "ZoneSeq", x: "ZoneX", y: "ZoneY" },
    outsideLabel: "Outside",
    outsideColor: { color: "#a6a6a6", index: -1 },
    showOutlines: true,
    showZoneTags: true,
    colorBy: "zone",
    pointRadius: 1.35,
    cellSize: 5,
    underlay: 4,
    maxPoints: 1000000,
    zoom: true,
    toolbar: true,
    legend: true,
  },
};

const zoneItems = {
  label: { ref: "label", label: "Label", type: "string", expression: "optional", defaultValue: "Zone" },
  show: {
    ref: "show",
    label: "Show",
    type: "boolean",
    component: "switch",
    options: [
      { value: true, label: "On" },
      { value: false, label: "Off" },
    ],
    defaultValue: true,
  },
  kind: {
    ref: "kind",
    label: "Zone type",
    type: "string",
    component: "dropdown",
    defaultValue: "band",
    options: [
      { value: "band", label: "Horizontal band (Y min/max)" },
      { value: "rect", label: "Rectangle (X and Y min/max)" },
      { value: "envelope", label: "Envelope along X (upper/lower points)" },
    ],
  },
  yMin: num("yMin", "Y min", -1, isNotKind("envelope")),
  yMax: num("yMax", "Y max", 1, isNotKind("envelope")),
  xMin: num("xMin", "X min", 0, isKind("rect")),
  xMax: num("xMax", "X max", 1, isKind("rect")),
  mirror: {
    ref: "mirror",
    label: "Lower edge mirrors upper (−y)",
    type: "boolean",
    component: "switch",
    options: [
      { value: true, label: "On" },
      { value: false, label: "Off" },
    ],
    defaultValue: true,
    show: isKind("envelope"),
  },
  upper: pointList("upper", "Upper edge", "Add point", isKind("envelope")),
  lower: pointList("lower", "Lower edge", "Add point", (d: any) => isKind("envelope")(d) && d.mirror === false),
  color: {
    ref: "color",
    label: "Color",
    type: "object",
    component: "color-picker",
    dualOutput: true,
    defaultValue: { index: -1, color: null },
  },
};

export const definition = {
  type: "items",
  component: "accordion",
  items: {
    data: { uses: "data" },
    sorting: { uses: "sorting" },
    addons: {
      type: "items",
      component: "expandable-items",
      translation: "properties.addons",
      items: {
        zones: {
          type: "items",
          label: "Zones",
          items: {
            zoneSource: {
              ref: "props.zoneSource",
              label: "Zones from",
              type: "string",
              component: "buttongroup",
              defaultValue: "props",
              options: [
                { value: "props", label: "Properties" },
                { value: "data", label: "Data model" },
              ],
            },
            zoneFieldsHeader: {
              component: "text",
              label: "Zone table: one row per vertex. Edge = upper/lower (envelope, ordered by Seq; no lower rows = mirrored) or min/max (rectangle corners; empty X = horizontal band). Color = hex or palette index.",
              show: (d: any) => d.props?.zoneSource === "data",
            },
            ...Object.fromEntries(
              [
                ["id", "Zone ID field"],
                ["label", "Label field"],
                ["color", "Color field"],
                ["edge", "Edge field"],
                ["seq", "Seq field"],
                ["x", "X field"],
                ["y", "Y field"],
              ].map(([k, label]) => [
                `zf_${k}`,
                { ref: `props.zoneFields.${k}`, label: label, type: "string", show: (d: any) => d.props?.zoneSource === "data" },
              ]),
            ),
            zoneList: {
              type: "array",
              ref: "props.zones",
              label: "Zones (first match wins — inner to outer)",
              itemTitleRef: "label",
              allowAdd: true,
              allowRemove: true,
              allowMove: true,
              addTranslation: "Add zone",
              show: (d: any) => d.props?.zoneSource !== "data",
              items: zoneItems,
            },
            outsideLabel: { ref: "props.outsideLabel", label: "Outside label", type: "string", expression: "optional" },
            outsideColor: {
              ref: "props.outsideColor",
              label: "Outside color",
              type: "object",
              component: "color-picker",
              dualOutput: true,
            },
            showOutlines: {
              ref: "props.showOutlines",
              label: "Zone outlines",
              type: "boolean",
              component: "switch",
              options: [
                { value: true, label: "On" },
                { value: false, label: "Off" },
              ],
            },
          },
        },
        dataHandling: {
          uses: "dataHandling",
          items: {
            calcCond: { uses: "calcCond" },
            maxPoints: {
              ref: "props.maxPoints",
              label: "Max points fetched",
              type: "number",
              defaultValue: 1000000,
              min: 1000,
              max: 2000000,
            },
          },
        },
      },
    },
    appearance: {
      uses: "settings",
      items: {
        presentation: {
          type: "items",
          label: "Presentation",
          grouped: true,
          items: {
            colorBy: {
              ref: "props.colorBy",
              label: "Color by",
              type: "string",
              component: "dropdown",
              options: [
                { value: "zone", label: "Zone" },
                { value: "density", label: "Density only" },
                { value: "value", label: "Color measure (3rd measure)" },
                { value: "category", label: "Category (2nd dimension)" },
              ],
            },
            pointRadius: {
              ref: "props.pointRadius",
              label: "Point size",
              type: "number",
              component: "slider",
              min: 0.5,
              max: 4,
              step: 0.05,
            },
            cellSize: {
              ref: "props.cellSize",
              label: "Density cell size (px)",
              type: "number",
              component: "slider",
              min: 2,
              max: 12,
              step: 1,
            },
            underlay: {
              ref: "props.underlay",
              label: "Density underlay threshold (points per cell, 0 = off)",
              type: "number",
              defaultValue: 4,
            },
            legend: {
              ref: "props.legend",
              label: "Legend",
              type: "boolean",
              component: "switch",
              options: [
                { value: true, label: "Show" },
                { value: false, label: "Hide" },
              ],
            },
            showZoneTags: {
              ref: "props.showZoneTags",
              label: "Zone tags in plot",
              type: "boolean",
              component: "switch",
              options: [
                { value: true, label: "Show" },
                { value: false, label: "Hide" },
              ],
            },
            zoom: {
              ref: "props.zoom",
              label: "Zoom and pan",
              type: "boolean",
              component: "switch",
              options: [
                { value: true, label: "On" },
                { value: false, label: "Off" },
              ],
            },
            toolbar: {
              ref: "props.toolbar",
              label: "Selection toolbar (pointer / range / lasso)",
              type: "boolean",
              component: "switch",
              options: [
                { value: true, label: "Show" },
                { value: false, label: "Hide" },
              ],
            },
          },
        },
      },
    },
  },
};

export const dataTargets = [
  {
    path: "/qHyperCubeDef",
    dimensions: {
      min: 1,
      max: 2,
      description: (_props: unknown, index: number) => (index === 0 ? "Point identity (one row per point)" : "Category (color by)"),
    },
    measures: {
      min: 2,
      max: 3,
      description: (_props: unknown, index: number) => ["X axis", "Y axis", "Color value"][index] ?? "Measure",
    },
  },
];
