/**
 * qixHighDScatter — nebula.js supernova entry.
 * The build wraps this module as AMD with `@nebula.js/stardust` as the only
 * external (the only module guaranteed on Qlik Cloud and client-managed).
 */
import * as stardust from "@nebula.js/stardust";
import { createRoot, type Root } from "react-dom/client";
import { App } from "./App";
import { mapTheme } from "./theme";
import { dataTargets, definition, initialProperties } from "./properties";
import css from "./styles.generated.css";

const VERSION = "__QHDS_VERSION__";
const S: any = stardust;
const HAS_INTERACTIONS = typeof S.useInteractionState === "function";

let cssInjected = false;
function injectCss() {
  if (cssInjected || typeof document === "undefined") return;
  cssInjected = true;
  const el = document.createElement("style");
  el.setAttribute("data-qhds", VERSION);
  el.textContent = css;
  document.head.appendChild(el);
}

interface Mount {
  root: Root;
  host: HTMLDivElement;
}

export default function supernova(env: any) {
  return {
    qae: {
      properties: { initial: initialProperties },
      data: { targets: dataTargets },
    },
    ext: {
      definition,
      support: { snapshot: false, export: false, exportData: true, sharing: false, viewData: true },
    },
    component() {
      const element: HTMLElement = S.useElement();
      const layout = S.useLayout();
      const model = S.useModel();
      const app = S.useApp ? S.useApp() : null;
      const selections = S.useSelections();
      const theme = S.useTheme();
      const rect = S.useRect ? S.useRect() : { width: element.clientWidth, height: element.clientHeight };
      // Newer stardust: useInteractionState; older (client-managed): useConstraints.
      // (interactions use inverted values: `true` = allowed; constraints: `true` = disabled)
      const interaction = HAS_INTERACTIONS ? S.useInteractionState() : null;
      const constraints = HAS_INTERACTIONS ? null : S.useConstraints ? S.useConstraints() : {};
      const [mount] = S.useState(() => ({ current: null as Mount | null }));

      S.useEffect(() => {
        injectCss();
        const host = document.createElement("div");
        host.className = "qhds";
        host.setAttribute("data-qhds-version", VERSION);
        element.appendChild(host);
        mount.current = { root: createRoot(host), host };
        return () => {
          const m = mount.current;
          mount.current = null;
          if (m) {
            m.root.unmount();
            m.host.remove();
          }
        };
      }, [element]);

      S.useEffect(() => {
        const m = mount.current;
        if (!m || !layout) return;
        const mapped = mapTheme(theme);
        for (const [k, v] of Object.entries(mapped.vars)) m.host.style.setProperty(k, v);
        m.host.style.fontFamily = mapped.fontFamily;
        m.host.setAttribute("data-theme", mapped.dark ? "dark" : "light");
        // `passive` here = no interaction at all (snapshot/print); `canActive` = zoom/pan; select = selections.
        const canActive = interaction ? interaction.active !== false : !constraints?.active;
        const passive = interaction ? interaction.passive === false && !canActive : Boolean(constraints?.passive && constraints?.active);
        const selectAllowed = interaction
          ? interaction.select !== false && !interaction.edit && canActive
          : !constraints?.select && !constraints?.active;
        const w = Math.floor(rect?.width ?? element.clientWidth);
        const h = Math.floor(rect?.height ?? element.clientHeight);
        m.root.render(
          <App
            layout={layout}
            model={model}
            app={app}
            selections={selections}
            theme={mapped}
            width={w}
            height={h}
            canSelect={selectAllowed && !passive}
            passive={passive || !canActive}
          />,
        );
      }, [layout, theme, rect?.width, rect?.height, interaction, constraints, selections, model, app]);
    },
  };
}
